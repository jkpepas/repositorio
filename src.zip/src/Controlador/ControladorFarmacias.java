
package Controlador;

import java.util.ArrayList;
import modelo.Farmacias;
import modelo.FarmaciasDAO;
public class ControladorFarmacias {
 
    
     public static ArrayList<Farmacias> listadoFarmacias()
    {
         return FarmaciasDAO.listadoFarmacias();
    }
    
    
    public static Farmacias buscarFarmacias(String farma_codi)
    {
         return FarmaciasDAO.buscarFarmacias(farma_codi);
    }
    
    public static int grabarFarmacias(Farmacias p)
    {
        FarmaciasDAO farmaciasDAO = new FarmaciasDAO();
        int resultado = farmaciasDAO.grabarFarmacias(p);
        return resultado; 
    }
    
    public static ArrayList<Farmacias> listarFarmacias(int farma_codi)
    {
        ArrayList<Farmacias> listado;
        listado = new ArrayList();
        FarmaciasDAO farmaciasDAO = new FarmaciasDAO();
        listado = farmaciasDAO.listarFarmacias(farma_codi);
        return listado; 
    }
    
    public static int borrarFarmacias(int farma_codi)
    {
        FarmaciasDAO farmaciasDAO = new FarmaciasDAO();
        int resultado = farmaciasDAO.borrarFarmacias(farma_codi);
        return resultado; 
    }
    
    public static int modificarFarmacias(Farmacias m)
    {
        FarmaciasDAO farmaciasDAO = new FarmaciasDAO();
        int resultado = farmaciasDAO.modificarFarmacias(m);
        return resultado; 
    }
}
