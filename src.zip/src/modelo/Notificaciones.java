
package modelo;


public class Notificaciones {
    
    private int noti_codi;
    private String noti_desc;
    private int farma_codi;
    private String farma_nomb;
    private int cli_codi;
    private String cli_nomb;
    
    public Notificaciones(){
        noti_codi = 0;
        noti_desc = " ";
        farma_codi = 0;
        cli_codi = 0;
    }

    public Notificaciones(int noti_codi, String noti_desc, int farma_codi, String farma_nomb, int cli_codi, String cli_nomb) {
        this.noti_codi = noti_codi;
        this.noti_desc = noti_desc;
        this.farma_codi = farma_codi;
        this.farma_nomb = farma_nomb;
        this.cli_codi = cli_codi;
        this.cli_nomb = cli_nomb;
    }

    public int getNoti_codi() {
        return noti_codi;
    }

    public void setNoti_codi(int noti_codi) {
        this.noti_codi = noti_codi;
    }

    public String getNoti_desc() {
        return noti_desc;
    }

    public void setNoti_desc(String noti_desc) {
        this.noti_desc = noti_desc;
    }

    public int getFarma_codi() {
        return farma_codi;
    }

    public void setFarma_codi(int farma_codi) {
        this.farma_codi = farma_codi;
    }

    public String getFarma_nomb() {
        return farma_nomb;
    }

    public void setFarma_nomb(String farma_nomb) {
        this.farma_nomb = farma_nomb;
    }

    public int getCli_codi() {
        return cli_codi;
    }

    public void setCli_codi(int cli_codi) {
        this.cli_codi = cli_codi;
    }

    public String getCli_nomb() {
        return cli_nomb;
    }

    public void setCli_nomb(String cli_nomb) {
        this.cli_nomb = cli_nomb;
    }

   
    
    

    
    
}
