
package modelo;
import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Ciudades {
    private int  ciu_codi;
    private String ciu_nomb;
    private int  pais_codi;
    private String pais_nomb;
    
     public Ciudades(){
        ciu_codi = 0;
        ciu_nomb = "";
        pais_codi = 0;
        pais_nomb = "";
    }

    public Ciudades(int ciu_codi, String ciu_nomb, int pais_codi, String pais_nomb) {
        this.ciu_codi = ciu_codi;
        this.ciu_nomb = ciu_nomb;
        this.pais_codi = pais_codi;
        this.pais_nomb = pais_nomb;
    }

    
    
    public String toString(){
        return this.getCiu_nomb();
    }

    public int getCiu_codi() {
        return ciu_codi;
    }

    public void setCiu_codi(int ciu_codi) {
        this.ciu_codi = ciu_codi;
    }

    public String getCiu_nomb() {
        return ciu_nomb;
    }

    public void setCiu_nomb(String ciu_nomb) {
        this.ciu_nomb = ciu_nomb;
    }

    public int getPais_codi() {
        return pais_codi;
    }

    public void setPais_codi(int pais_codi) {
        this.pais_codi = pais_codi;
    }

    public String getPais_nomb() {
        return pais_nomb;
    }

    public void setPais_nomb(String pais_nomb) {
        this.pais_nomb = pais_nomb;
    }
     
     
}
