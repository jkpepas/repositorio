/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import java.util.ArrayList;
import modelo.Inventarios;
import modelo.InventariosDAO;
public class ControladorInventarios {
    
  public static ArrayList<Inventarios> listadoInventarios()
    {
         return InventariosDAO.listadoInventarios();
    }
    
    
    public static Inventarios buscarInventarios(String inven_codi)
    {
         return InventariosDAO.buscarInventarios(inven_codi);
    }
    
    public static int grabarInventarios(Inventarios m)
    {
        InventariosDAO inventariosDAO = new InventariosDAO();
        int resultado = inventariosDAO.grabarInventarios(m);
        return resultado; 
    }
    
    public static ArrayList<Inventarios> listarInventarios(int inven_codi)
    {
        ArrayList<Inventarios> listado;
        listado = new ArrayList();
        InventariosDAO inventariosDAO = new InventariosDAO();
        listado = inventariosDAO.listarInventarios(inven_codi);
        return listado; 
    }
    
    public static int borrarInventarios(int inven_codi)
    {
        InventariosDAO inventariosDAO = new InventariosDAO();
        int resultado = inventariosDAO.borrarInventarios(inven_codi);
        return resultado; 
    }
    
    public static int modificarInventarios(Inventarios m)
    {
        InventariosDAO inventariosDAO = new InventariosDAO();
        int resultado = inventariosDAO.modificarInventarios(m);
        return resultado; 
    }
    
}
