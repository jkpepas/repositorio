/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;



import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author pablo
 */
public class NotificacionesDAO {

    public NotificacionesDAO() {
    }
    
    public static ArrayList<Notificaciones> listadoNotificaciones(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Notificaciones> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_notificaciones ORDER BY noti_desc";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Notificaciones noti = null;
            while(rs.next()){
                noti = new Notificaciones();
                noti.setNoti_codi(rs.getInt("noti_codi"));
                noti.setNoti_desc(rs.getString("noti_desc"));
                noti.setFarma_codi(rs.getInt("farma_codi"));
                noti.setCli_codi(rs.getInt("cli_codi"));
                listado.add(noti);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Notificaciones buscarNotificaciones(String noti_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Notificaciones noti = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_notificaciones WHERE noti_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, noti_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                noti = new Notificaciones();
                noti.setNoti_codi(rs.getInt("noti_codi"));
                noti.setNoti_desc(rs.getString("noti_desc"));
                noti.setFarma_codi(rs.getInt("farma_codi"));
                noti.setCli_codi(rs.getInt("cli_codi"));  
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return noti;
    }
    
    public int grabarNotificaciones(Notificaciones c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_notificaciones values (?,?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getNoti_codi());
            pstm.setString(2, c.getNoti_desc());
            pstm.setInt(3, c.getFarma_codi());
            pstm.setInt(4,c.getCli_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarNotificaciones(Notificaciones c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_notificaciones " +
                        "SET noti_desc=?,farma_codi=?,cli_codi=? WHERE noti_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getNoti_desc());
            pstm.setInt(2,c.getFarma_codi());
            pstm.setInt(3, c.getCli_codi());
            pstm.setInt(4,c.getNoti_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarNotificaciones(int noti_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_notificaciones WHERE noti_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, noti_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Notificaciones> listarNotificaciones(int noti_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Notificaciones> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(noti_codi==0){
                sql = "SELECT * FROM tb_notificaciones as m "
                        + "INNER JOIN tb_farmacias "
                    + "as d ON (d.farma_codi = m.farma_codi) "
                        + "INNER JOIN tb_clientes"
                        + " as p ON (p.cli_codi = m.cli_codi)"
                        + "ORDER BY noti_codi";            
            }else{
                sql = "SELECT * FROM tb_notificaciones as m "
                        + "INNER JOIN tb_farmacias "
                    + "as d ON (d.farma_codi = m.farma_codi) "
                        + "INNER JOIN tb_clientes"
                        + " as p ON (p.cli_codi = m.cli_codi)"
                        + "where noti_codi = ? "
                        + "ORDER BY noti_codi";       
            }                        
            pstm = con.prepareStatement(sql);
            
            if(noti_codi!=0){
                pstm.setInt(1, noti_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Notificaciones noti = null;
            while(rs.next()){
                noti = new Notificaciones();
                noti.setNoti_codi(rs.getInt("noti_codi"));
                noti.setNoti_desc(rs.getString("noti_desc"));
                noti.setFarma_codi(rs.getInt("farma_codi"));
                noti.setFarma_nomb(rs.getString("farma_nomb"));
                noti.setCli_codi(rs.getInt("cli_codi"));
                noti.setCli_nomb(rs.getString("cli_nomb"));
                listado.add(noti);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
}
