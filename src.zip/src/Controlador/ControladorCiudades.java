/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import java.util.ArrayList;
import modelo.Ciudades;
import modelo.CiudadesDAO;
public class ControladorCiudades {
    
  public static ArrayList<Ciudades> listadoCiudades()
    {
         return CiudadesDAO.listadoCiudades();
    }
    
    
    public static Ciudades buscarCiudades(String ciu_codi)
    {
         return CiudadesDAO.buscarCiudades(ciu_codi);
    }
    
    public static int grabarCiudades(Ciudades m)
    {
        CiudadesDAO ciudadesDAO = new CiudadesDAO();
        int resultado = ciudadesDAO.grabarCiudades(m);
        return resultado; 
    }
    
    public static ArrayList<Ciudades> listarCiudades(int ciu_codi)
    {
        ArrayList<Ciudades> listado;
        listado = new ArrayList();
        CiudadesDAO ciudadesDAO = new CiudadesDAO();
        listado = ciudadesDAO.listarCiudades(ciu_codi);
        return listado; 
    }
    
    public static int borrarCiudades(int ciu_codi)
    {
        CiudadesDAO ciudadesDAO = new CiudadesDAO();
        int resultado = ciudadesDAO.borrarCiudades(ciu_codi);
        return resultado; 
    }
    
    public static int modificarCiudades(Ciudades m)
    {
        CiudadesDAO ciudadesDAO = new CiudadesDAO();
        int resultado = ciudadesDAO.modificarCiudades(m);
        return resultado; 
    }
    
}
