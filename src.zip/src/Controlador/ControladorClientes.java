
package Controlador;

import java.util.ArrayList;
import modelo.Clientes;
import modelo.ClientesDAO;
public class ControladorClientes {
 
    
     public static ArrayList<Clientes> listadoClientes()
    {
         return ClientesDAO.listadoClientes();
    }
    
    
    public static Clientes buscarClientes(String cli_codi)
    {
         return ClientesDAO.buscarClientes(cli_codi);
    }
    
    public static int grabarClientes(Clientes p)
    {
        ClientesDAO clientesDAO = new ClientesDAO();
        int resultado = clientesDAO.grabarClientes(p);
        return resultado; 
    }
    
    public static ArrayList<Clientes> listarClientes(int cli_codi)
    {
        ArrayList<Clientes> listado;
        listado = new ArrayList();
        ClientesDAO clientesDAO = new ClientesDAO();
        listado = clientesDAO.listarClientes(cli_codi);
        return listado; 
    }
    
    public static int borrarClientes(int cli_codi)
    {
        ClientesDAO clientesDAO = new ClientesDAO();
        int resultado = clientesDAO.borrarClientes(cli_codi);
        return resultado; 
    }
    
    public static int modificarClientes(Clientes m)
    {
        ClientesDAO clientesDAO = new ClientesDAO();
        int resultado = clientesDAO.modificarClientes(m);
        return resultado; 
    }
}
