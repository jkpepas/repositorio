/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PaisesDAO {
     public PaisesDAO(){
        
    }
    
    public static ArrayList<Paises> listadoPaises(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Paises> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_paises ORDER BY pais_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Paises pais = null;
            while(rs.next()){
                pais = new Paises();
                pais.setPais_codi(rs.getInt("pais_codi"));
                pais.setPais_nomb(rs.getString("pais_nomb"));
                listado.add(pais);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarPaises(Paises g){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_paises values (?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, g.getPais_codi());
            pstm.setString(2, g.getPais_nomb());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarPaises(Paises g){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_paises " +
                        "SET pais_nomb=? WHERE pais_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, g.getPais_nomb());
            pstm.setInt(2,g.getPais_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarPaises(int pais_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_paises WHERE pais_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, pais_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Paises> listarPaises(int pais_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Paises> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(pais_codi==0){
                sql = "SELECT * FROM tb_paises  ORDER BY pais_codi";            
            }else{
                sql = "SELECT * FROM tb_paises  where pais_codi = ? "
                    + "ORDER BY pais_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(pais_codi!=0){
                pstm.setInt(1, pais_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Paises pais = null;
            while(rs.next()){
                pais = new Paises();
                pais.setPais_codi(rs.getInt("pais_codi"));
                pais.setPais_nomb(rs.getString("pais_nomb"));
                listado.add(pais);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Paises buscarPaises(String pais_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Paises paises = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_paises WHERE pais_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, pais_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                paises = new Paises();
                paises.setPais_codi(rs.getInt("pais_codi"));
                paises.setPais_nomb(rs.getString("pais_nomb"));
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return paises;
    }
    
}
