
package modelo;
import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Nomina {
    private int  pago_codi;
    private int pago_cant;
    private int  emple_codi;
    private String emple_nomb;

public Nomina(){
        pago_codi = 0;
        pago_cant = 0;
        emple_codi = 0;
        emple_nomb = "";
}

    public Nomina(int pago_codi, int pago_cant, int emple_codi, String emple_nomb) {
        this.pago_codi = pago_codi;
        this.pago_cant = pago_cant;
        this.emple_codi = emple_codi;
        this.emple_nomb = emple_nomb;
    }

    public int getPago_codi() {
        return pago_codi;
    }

    public void setPago_codi(int pago_codi) {
        this.pago_codi = pago_codi;
    }

    public int getPago_cant() {
        return pago_cant;
    }

    public void setPago_cant(int pago_cant) {
        this.pago_cant = pago_cant;
    }

    public int getEmple_codi() {
        return emple_codi;
    }

    public void setEmple_codi(int emple_codi) {
        this.emple_codi = emple_codi;
    }

    public String getEmple_nomb() {
        return emple_nomb;
    }

    public void setEmple_nomb(String emple_nomb) {
        this.emple_nomb = emple_nomb;
    }

}