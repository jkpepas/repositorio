
package modelo;

import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Productos {
     private int produ_codi;
    private String produ_nomb;
    
     public Productos(){
        produ_codi = 0;
        produ_nomb = "";
     }

    public Productos(int produ_codi, String produ_nomb) {
        this.produ_codi = produ_codi;
        this.produ_nomb = produ_nomb;
    }
     
     
      public String toString(){
        return this.getProdu_nomb();
    }

    public int getProdu_codi() {
        return produ_codi;
    }

    public void setProdu_codi(int produ_codi) {
        this.produ_codi = produ_codi;
    }

    public String getProdu_nomb() {
        return produ_nomb;
    }

    public void setProdu_nomb(String produ_nomb) {
        this.produ_nomb = produ_nomb;
    }
      
      
}
