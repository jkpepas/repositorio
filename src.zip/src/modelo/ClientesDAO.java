package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClientesDAO {
    
    public ClientesDAO(){
        
    }
    
    public static ArrayList<Clientes> listadoClientes(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Clientes> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_clientes ORDER BY cli_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Clientes cli = null;
            while(rs.next()){
                cli = new Clientes();
                cli.setCli_codi(rs.getInt("cli_codi"));
                cli.setCli_nomb(rs.getString("cli_nomb"));
                cli.setCli_ape(rs.getString("cli_ape"));
                cli.setCli_tele(rs.getInt("cli_tele"));
                
                listado.add(cli);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarClientes(Clientes p){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_clientes values (?,?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, p.getCli_codi());
            pstm.setString(2, p.getCli_nomb());
            pstm.setString(3, p.getCli_ape());
            pstm.setInt(4, p.getCli_tele());
            
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarClientes(Clientes c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_clientes " +
                        "SET cli_nomb=?,cli_ape=?,cli_tele=? WHERE cli_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getCli_nomb());
            pstm.setString(2, c.getCli_ape());
            pstm.setInt(3,c.getCli_tele());
            pstm.setInt(4,c.getCli_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarClientes(int cli_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_clientes WHERE cli_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, cli_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Clientes> listarClientes(int cli_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Clientes> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(cli_codi==0){
                sql = "SELECT * FROM tb_clientes  ORDER BY cli_codi";            
            }else{
                sql = "SELECT * FROM tb_clientes  where cli_codi = ? "
                    + "ORDER BY cli_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(cli_codi!=0){
                pstm.setInt(1, cli_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Clientes cli = null;
            while(rs.next()){
                cli = new Clientes();
                cli.setCli_codi(rs.getInt("cli_codi"));
                cli.setCli_nomb(rs.getString("cli_nomb"));
                cli.setCli_ape(rs.getString("cli_ape"));
                cli.setCli_tele(rs.getInt("cli_tele"));
                
                listado.add(cli);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Clientes buscarClientes(String cli_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Clientes cli = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_clientes WHERE cli_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, cli_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                cli = new Clientes();
                cli.setCli_codi(rs.getInt("cli_codi"));
                cli.setCli_nomb(rs.getString("cli_nomb"));
                cli.setCli_ape(rs.getString("cli_ape"));
                cli.setCli_tele(rs.getInt("cli_tele"));
                
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return cli;
    }
    
}
