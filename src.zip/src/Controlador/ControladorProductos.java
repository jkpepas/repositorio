
package Controlador;

import java.util.ArrayList;
import modelo.Productos;
import modelo.ProductosDAO;
public class ControladorProductos {
 
    
     public static ArrayList<Productos> listadoProductos()
    {
         return ProductosDAO.listadoProductos();
    }
    
    
    public static Productos buscarProductos(String produ_codi)
    {
         return ProductosDAO.buscarProductos(produ_codi);
    }
    
    public static int grabarProductos(Productos p)
    {
        ProductosDAO productosDAO = new ProductosDAO();
        int resultado = productosDAO.grabarProductos(p);
        return resultado; 
    }
    
    public static ArrayList<Productos> listarProductos(int produ_codi)
    {
        ArrayList<Productos> listado;
        listado = new ArrayList();
        ProductosDAO productosDAO = new ProductosDAO();
        listado = productosDAO.listarProductos(produ_codi);
        return listado; 
    }
    
    public static int borrarProductos(int produ_codi)
    {
        ProductosDAO productosDAO = new ProductosDAO();
        int resultado = productosDAO.borrarProductos(produ_codi);
        return resultado; 
    }
    
    public static int modificarProductos(Productos m)
    {
        ProductosDAO productosDAO = new ProductosDAO();
        int resultado = productosDAO.modificarProductos(m);
        return resultado; 
    }
}
