
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PropietariosDAO {
    
    public PropietariosDAO(){
        
    }
    
    public static ArrayList<Propietarios> listadoPropietarios(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Propietarios> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_propietarios ORDER BY propi_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Propietarios propi = null;
            while(rs.next()){
                propi = new Propietarios();
                propi.setPropi_codi(rs.getInt("propi_codi"));
                propi.setPropi_nomb(rs.getString("propi_nomb"));
                listado.add(propi);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarPropietarios(Propietarios p){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_propietarios values (?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, p.getPropi_codi());
            pstm.setString(2, p.getPropi_nomb());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarPropietarios(Propietarios c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_propietarios " +
                        "SET propi_nomb=? WHERE propi_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getPropi_nomb());
            pstm.setInt(2,c.getPropi_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarPropietarios(int propi_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_propietarios WHERE propi_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, propi_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Propietarios> listarPropietarios(int propi_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Propietarios> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(propi_codi==0){
                sql = "SELECT * FROM tb_propietarios  ORDER BY propi_codi";            
            }else{
                sql = "SELECT * FROM tb_propietarios  where propi_codi = ? "
                    + "ORDER BY propi_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(propi_codi!=0){
                pstm.setInt(1, propi_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Propietarios propi = null;
            while(rs.next()){
                propi = new Propietarios();
                propi.setPropi_codi(rs.getInt("propi_codi"));
                propi.setPropi_nomb(rs.getString("propi_nomb"));
                listado.add(propi);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Propietarios buscarPropietarios(String propi_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Propietarios propi = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_propietarios WHERE propi_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, propi_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                propi = new Propietarios();
                propi.setPropi_codi(rs.getInt("propi_codi"));
                propi.setPropi_nomb(rs.getString("propi_nomb"));
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return propi;
    }
}
