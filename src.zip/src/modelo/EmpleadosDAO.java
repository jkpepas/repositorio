package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class EmpleadosDAO {
        
        public EmpleadosDAO(){
        }
        
        public static ArrayList<Empleados> listadoEmpleados(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Empleados> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_empleados ORDER BY emple_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Empleados empleado = null;
            while(rs.next()){
                empleado = new Empleados();
                empleado.setEmple_codi(rs.getInt("emple_codi"));
                empleado.setEmple_nomb(rs.getString("emple_nomb"));
                empleado.setFarma_codi(rs.getInt("farma_codi"));
                listado.add(empleado);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Empleados buscarEmpleados(String emple_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Empleados empleado = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_empleados WHERE emple_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, emple_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                empleado = new Empleados();
                empleado.setEmple_codi(rs.getInt("emple_codi"));
                empleado.setEmple_nomb(rs.getString("emple_nomb"));
                empleado.setFarma_codi(rs.getInt("farma_codi"));           
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return empleado;
    }
    
    public int grabarEmpleados(Empleados c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_empleados values (?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getEmple_codi());
            pstm.setString(2, c.getEmple_nomb());
            pstm.setInt(3,c.getFarma_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarEmpleados(Empleados c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_empleados " +
                        "SET emple_nomb=?,farma_codi=? WHERE emple_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getEmple_nomb());
            pstm.setInt(2,c.getFarma_codi());
            pstm.setInt(3,c.getEmple_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarEmpleados(int emple_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_empleados WHERE emple_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, emple_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Empleados> listarEmpleados(int emple_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Empleados> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(emple_codi==0){
                sql = "SELECT * FROM tb_empleados as m INNER JOIN tb_farmacias "
                    + "as d ON (d.farma_codi = m.farma_codi) ORDER BY emple_codi";            
            }else{
                sql = "SELECT * FROM tb_empleados as m INNER JOIN tb_farmacias "
                    + "as d ON (d.farma_codi = m.farma_codi) where emple_codi = ? "
                    + "ORDER BY emple_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(emple_codi!=0){
                pstm.setInt(1, emple_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Empleados empleado = null;
            while(rs.next()){
                empleado = new Empleados();
                empleado.setEmple_codi(rs.getInt("emple_codi"));
                empleado.setEmple_nomb(rs.getString("emple_nomb"));
                empleado.setFarma_codi(rs.getInt("farma_codi"));
                empleado.setFarma_nomb(rs.getString("farma_nomb"));
                listado.add(empleado);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
}
