
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class RolDAO {
    
    public RolDAO(){
        
    }
    
    public static ArrayList<Rol> listadoRol(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Rol> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_roles ORDER BY rol_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Rol rol = null;
            while(rs.next()){
                rol = new Rol();
                rol.setRol_codi(rs.getInt("rol_codi"));
                rol.setRol_nomb(rs.getString("rol_nomb"));
                rol.setRol_desc(rs.getString("rol_desc"));
                
                listado.add(rol);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarRol(Rol p){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_roles values (?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, p.getRol_codi());
            pstm.setString(2, p.getRol_nomb());
            pstm.setString(3, p.getRol_desc());
            
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarRol(Rol c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_roles " +
                        "SET rol_nomb=?,rol_desc=? WHERE rol_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getRol_nomb());
            pstm.setString(2, c.getRol_desc());
            pstm.setInt(3,c.getRol_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarRol(int rol_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_roles WHERE rol_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, rol_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Rol> listarRol(int rol_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Rol> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(rol_codi==0){
                sql = "SELECT * FROM tb_roles  ORDER BY rol_codi";            
            }else{
                sql = "SELECT * FROM tb_roles  where rol_codi = ? "
                    + "ORDER BY rol_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(rol_codi!=0){
                pstm.setInt(1, rol_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Rol rol = null;
            while(rs.next()){
                rol = new Rol();
                rol.setRol_codi(rs.getInt("rol_codi"));
                rol.setRol_nomb(rs.getString("rol_nomb"));
                rol.setRol_desc(rs.getString("rol_desc"));
                
                listado.add(rol);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Rol buscarRol(String rol_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Rol rol = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_roles WHERE rol_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, rol_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                rol = new Rol();
                rol.setRol_codi(rs.getInt("rol_codi"));
                rol.setRol_nomb(rs.getString("rol_nomb"));
                rol.setRol_desc(rs.getString("rol_desc"));
                
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return rol;
    }
    
}
