/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import java.util.ArrayList;
import modelo.Empleados;
import modelo.EmpleadosDAO;
public class ControladorEmpleados {
    
  public static ArrayList<Empleados> listadoEmpleados()
    {
         return EmpleadosDAO.listadoEmpleados();
    }
    
    
    public static Empleados buscarEmpleados(String emple_codi)
    {
         return EmpleadosDAO.buscarEmpleados(emple_codi);
    }
    
    public static int grabarEmpleados(Empleados m)
    {
        EmpleadosDAO empleadosDAO = new EmpleadosDAO();
        int resultado = empleadosDAO.grabarEmpleados(m);
        return resultado; 
    }
    
    public static ArrayList<Empleados> listarEmpleados(int emple_codi)
    {
        ArrayList<Empleados> listado;
        listado = new ArrayList();
        EmpleadosDAO empleadosDAO = new EmpleadosDAO();
        listado = empleadosDAO.listarEmpleados(emple_codi);
        return listado; 
    }
    
    public static int borrarEmpleados(int emple_codi)
    {
        EmpleadosDAO empleadosDAO = new EmpleadosDAO();
        int resultado = empleadosDAO.borrarEmpleados(emple_codi);
        return resultado; 
    }
    
    public static int modificarEmpleados(Empleados m)
    {
        EmpleadosDAO empleadosDAO = new EmpleadosDAO();
        int resultado = empleadosDAO.modificarEmpleados(m);
        return resultado; 
    }
    
}
