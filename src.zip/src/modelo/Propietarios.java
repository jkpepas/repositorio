
package modelo;

import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Propietarios {
    private int propi_codi;
    private String propi_nomb;
    
     public Propietarios(){
        propi_codi = 0;
        propi_nomb = "";
     }

    public Propietarios(int propi_codi, String propi_nomb) {
        this.propi_codi = propi_codi;
        this.propi_nomb = propi_nomb;
    }
     
     public String toString(){
        return this.getPropi_nomb();
    }

    public int getPropi_codi() {
        return propi_codi;
    }

    public void setPropi_codi(int propi_codi) {
        this.propi_codi = propi_codi;
    }

    public String getPropi_nomb() {
        return propi_nomb;
    }

    public void setPropi_nomb(String propi_nomb) {
        this.propi_nomb = propi_nomb;
    }
     
     
}
