package modelo;
import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Empleados {
    private int  emple_codi;
    private String emple_nomb;
    private int  farma_codi;
    private String farma_nomb;
    
     public Empleados(){
        emple_codi = 0;
        emple_nomb = "";
        farma_codi = 0;
        farma_nomb = "";
    }

    public Empleados(int emple_codi, String emple_nomb, int farma_codi, String farma_nomb) {
        this.emple_codi = emple_codi;
        this.emple_nomb = emple_nomb;
        this.farma_codi = farma_codi;
        this.farma_nomb = farma_nomb;
    }

    
    
    public String toString(){
        return this.getEmple_nomb();
    }

    public int getEmple_codi() {
        return emple_codi;
    }

    public void setEmple_codi(int emple_codi) {
        this.emple_codi = emple_codi;
    }

    public String getEmple_nomb() {
        return emple_nomb;
    }

    public void setEmple_nomb(String emple_nomb) {
        this.emple_nomb = emple_nomb;
    }

    public int getFarma_codi() {
        return farma_codi;
    }

    public void setFarma_codi(int farma_codi) {
        this.farma_codi = farma_codi;
    }

    public String getFarma_nomb() {
        return farma_nomb;
    }

    public void setFarma_nomb(String farma_nomb) {
        this.farma_nomb = farma_nomb;
    }
     
     
}
