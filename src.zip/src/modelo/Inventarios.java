/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author pablo
 */
public class Inventarios {

    private int inven_codi;
    private int produ_codi;
    private String produ_nomb;
    private int cant;
    private String fecha;
    
    public Inventarios(){
        inven_codi = 0;
        produ_codi = 0;
        produ_nomb="";
        cant=0;
        fecha = "";
    }

    public Inventarios(int inven_codi, int produ_codi, String produ_nomb, int cant, String fecha) {
        this.inven_codi = inven_codi;
        this.produ_codi = produ_codi;
        this.produ_nomb = produ_nomb;
        this.cant = cant;
        this.fecha = fecha;
    }

    public int getInven_codi() {
        return inven_codi;
    }

    public void setInven_codi(int inven_codi) {
        this.inven_codi = inven_codi;
    }

    public int getProdu_codi() {
        return produ_codi;
    }

    public void setProdu_codi(int produ_codi) {
        this.produ_codi = produ_codi;
    }

    public String getProdu_nomb() {
        return produ_nomb;
    }

    public void setProdu_nomb(String produ_nomb) {
        this.produ_nomb = produ_nomb;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    
    
    
}
