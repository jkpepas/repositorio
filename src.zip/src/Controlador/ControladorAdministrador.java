
package Controlador;

import java.util.ArrayList;
import modelo.Administrador;
import modelo.AdministradorDAO;
public class ControladorAdministrador {
 
    
     public static ArrayList<Administrador> listadoAdministrador()
    {
         return AdministradorDAO.listadoAdministrador();
    }
    
    
    public static Administrador buscarAdministrador(String admin_codi)
    {
         return AdministradorDAO.buscarAdministrador(admin_codi);
    }
    
    public static int grabarAdministrador(Administrador p)
    {
        AdministradorDAO administradorDAO = new AdministradorDAO();
        int resultado = administradorDAO.grabarAdministrador(p);
        return resultado; 
    }
    
    public static ArrayList<Administrador> listarAdministrador(int admin_codi)
    {
        ArrayList<Administrador> listado;
        listado = new ArrayList();
        AdministradorDAO administradorDAO = new AdministradorDAO();
        listado = administradorDAO.listarAdministrador(admin_codi);
        return listado; 
    }
    
    public static int borrarAdministrador(int admin_codi)
    {
        AdministradorDAO administradorDAO = new AdministradorDAO();
        int resultado = administradorDAO.borrarAdministrador(admin_codi);
        return resultado; 
    }
    
    public static int modificarAdministrador(Administrador m)
    {
        AdministradorDAO administradorDAO = new AdministradorDAO();
        int resultado = administradorDAO.modificarAdministrador(m);
        return resultado; 
    }
}
