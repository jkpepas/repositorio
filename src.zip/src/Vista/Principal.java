/*
* Programa	: Principal.java
* Fecha		: 29/02/2016
* Objetivo	: Crea una instancia de la clase InterfazPricipal y visualiza
*                 la ventana principal
* Programador	: Luis Yovany Romo Portilla
*/

package Vista;

/**
 *
 * @author Admin
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Log ventana = new Log();
        ventana.setVisible(true);
      
    } 
}
