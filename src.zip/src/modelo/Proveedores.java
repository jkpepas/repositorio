
package modelo;

import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Proveedores {
    private int prove_codi;
    private String prove_nomb;
    
     public Proveedores(){
        prove_codi = 0;
        prove_nomb = "";
        
    }

    public Proveedores(int prove_codi, String prove_nomb) {
        this.prove_codi = prove_codi;
        this.prove_nomb = prove_nomb;
    }
     
     
     
     public String toString(){
        return this.getProve_nomb();
    }

    public int getProve_codi() {
        return prove_codi;
    }

    public void setProve_codi(int prove_codi) {
        this.prove_codi = prove_codi;
    }

    public String getProve_nomb() {
        return prove_nomb;
    }

    public void setProve_nomb(String prove_nomb) {
        this.prove_nomb = prove_nomb;
    }
     
     
}
