
package modelo;
import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Usuarios {
    private int usu_codi;
    private String usu_nomb;
    private String usu_pass;
    private int  rol_codi;
    private String rol_nomb;
    
     public Usuarios(){
        usu_codi = 0;
        usu_nomb = "";
        usu_pass = "";
        rol_codi = 0;
        rol_nomb = "";
     }

    public Usuarios(int usu_codi, String usu_nomb, String usu_pass, int rol_codi, String rol_nomb) {
        this.usu_codi = usu_codi;
        this.usu_nomb = usu_nomb;
        this.usu_pass = usu_pass;
        this.rol_codi = rol_codi;
        this.rol_nomb = rol_nomb;
    }
        
        
        
        public String toString(){
        return this.getUsu_nomb();
    }

    public int getUsu_codi() {
        return usu_codi;
    }

    public void setUsu_codi(int usu_codi) {
        this.usu_codi = usu_codi;
    }

    public String getUsu_nomb() {
        return usu_nomb;
    }

    public void setUsu_nomb(String usu_nomb) {
        this.usu_nomb = usu_nomb;
    }

    public String getUsu_pass() {
        return usu_pass;
    }

    public void setUsu_pass(String usu_pass) {
        this.usu_pass = usu_pass;
    }

    public int getRol_codi() {
        return rol_codi;
    }

    public void setRol_codi(int rol_codi) {
        this.rol_codi = rol_codi;
    }

    public String getRol_nomb() {
        return rol_nomb;
    }

    public void setRol_nomb(String rol_nomb) {
        this.rol_nomb = rol_nomb;
    }
        
        

}
