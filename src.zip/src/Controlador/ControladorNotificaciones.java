/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.util.ArrayList;
import modelo.Notificaciones;
import modelo.NotificacionesDAO;

/**
 *
 * @author pablo
 */
public class ControladorNotificaciones {
    
    public static ArrayList<Notificaciones> listadoNotificaciones()
    {
         return NotificacionesDAO.listadoNotificaciones();
    }
    
    
    public static Notificaciones buscarNotificaciones(String noti_codi)
    {
         return NotificacionesDAO.buscarNotificaciones(noti_codi);
    }
    
    public static int grabarNotificaciones(Notificaciones m)
    {
        NotificacionesDAO notificacionesDAO = new NotificacionesDAO();
        int resultado = notificacionesDAO.grabarNotificaciones(m);
        return resultado; 
    }
    
    public static ArrayList<Notificaciones> listarNotificaciones(int noti_codi)
    {
        ArrayList<Notificaciones> listado;
        listado = new ArrayList();
        NotificacionesDAO notificacionesDAO = new NotificacionesDAO();
        listado = notificacionesDAO.listarNotificaciones(noti_codi);
        return listado; 
    }
    
    public static int borrarNotificaciones(int noti_codi)
    {
        NotificacionesDAO notificacionesDAO = new NotificacionesDAO();
        int resultado = notificacionesDAO.borrarNotificaciones(noti_codi);
        return resultado; 
    }
    
    public static int modificarNotificaciones(Notificaciones m)
    {
        NotificacionesDAO notificacionesDAO = new NotificacionesDAO();
        int resultado = notificacionesDAO.modificarNotificaciones(m);
        return resultado; 
    }
    
}
