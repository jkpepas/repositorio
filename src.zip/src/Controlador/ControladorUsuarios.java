/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import java.util.ArrayList;
import modelo.Usuarios;
import modelo.UsuariosDAO;
public class ControladorUsuarios {
    
  public static ArrayList<Usuarios> listadoUsuarios()
    {
         return UsuariosDAO.listadoUsuarios();
    }
    
    
    public static Usuarios buscarUsuarios(String usu_codi)
    {
         return UsuariosDAO.buscarUsuarios(usu_codi);
    }
    
    public static int grabarUsuarios(Usuarios m)
    {
        UsuariosDAO usuariosDAO = new UsuariosDAO();
        int resultado = usuariosDAO.grabarUsuarios(m);
        return resultado; 
    }
    
    public static ArrayList<Usuarios> listarUsuarios(int usu_codi)
    {
        ArrayList<Usuarios> listado;
        listado = new ArrayList();
        UsuariosDAO usuariosDAO = new UsuariosDAO();
        listado = usuariosDAO.listarUsuarios(usu_codi);
        return listado; 
    }
    
    public static int borrarUsuarios(int usu_codi)
    {
        UsuariosDAO usuariosDAO = new UsuariosDAO();
        int resultado = usuariosDAO.borrarUsuarios(usu_codi);
        return resultado; 
    }
    
    public static int modificarUsuarios(Usuarios m)
    {
        UsuariosDAO usuariosDAO = new UsuariosDAO();
        int resultado = usuariosDAO.modificarUsuarios(m);
        return resultado; 
    }
    
}
