
package modelo;



import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class VentasDAO {

    public VentasDAO() {
    }
    
    public static ArrayList<Ventas> listadoVentas(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Ventas> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_ventas ORDER BY venta_codi";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Ventas ven = null;
            while(rs.next()){
                ven = new Ventas();
                ven.setVenta_codi(rs.getInt("venta_codi"));
                ven.setCli_codi(rs.getInt("cli_codi"));
                ven.setProdu_codi(rs.getInt("produ_codi"));
                ven.setProdu_cant(rs.getInt("produ_cant"));
                ven.setFecha(rs.getString("fecha"));
                listado.add(ven);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Ventas buscarVentas(String venta_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Ventas ven = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_ventas WHERE venta_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, venta_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                ven = new Ventas();
                ven.setVenta_codi(rs.getInt("venta_codi"));
                ven.setCli_codi(rs.getInt("cli_codi"));
                ven.setProdu_codi(rs.getInt("produ_codi"));
                ven.setProdu_cant(rs.getInt("produ_cant"));
                ven.setFecha(rs.getString("fecha"));  
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return ven;
    }
    
    public int grabarVentas(Ventas c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_ventas values (?,?,?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getVenta_codi());
            pstm.setInt(2, c.getCli_codi());
            pstm.setInt(3, c.getProdu_codi());
            pstm.setInt(4,c.getProdu_cant());
            pstm.setString(5,c.getFecha());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarVentas(Ventas c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_ventas " +
                        "SET cli_codi=?,produ_codi=?,produ_cant=?,fecha=?  WHERE venta_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setInt(1, c.getCli_codi());
            pstm.setInt(2,c.getProdu_codi());
            pstm.setInt(3, c.getProdu_cant());
            pstm.setString(4,c.getFecha());
            pstm.setInt(5,c.getVenta_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarVentas(int venta_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_ventas WHERE venta_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, venta_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Ventas> listarVentas(int venta_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Ventas> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(venta_codi==0){
                sql = "SELECT * FROM tb_ventas as m "
                        + "INNER JOIN tb_clientes "
                    + "as d ON (d.cli_codi = m.cli_codi) "
                        + "INNER JOIN tb_productos"
                        + " as p ON (p.produ_codi = m.produ_codi)"
                        + "ORDER BY venta_codi";            
            }else{
                sql = "SELECT * FROM tb_ventas as m "
                        + "INNER JOIN tb_clientes "
                    + "as d ON (d.cli_codi = m.cli_codi) "
                        + "INNER JOIN tb_productos"
                        + " as p ON (p.produ_codi = m.produ_codi)"
                        + "where venta_codi = ? "
                        + "ORDER BY venta_codi";       
            }                        
            pstm = con.prepareStatement(sql);
            
            if(venta_codi!=0){
                pstm.setInt(1, venta_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Ventas ven = null;
            while(rs.next()){
                ven = new Ventas();
                ven.setVenta_codi(rs.getInt("venta_codi"));
                ven.setCli_codi(rs.getInt("cli_codi"));
                ven.setCli_nomb(rs.getString("cli_nomb"));
                ven.setProdu_codi(rs.getInt("produ_codi"));
                ven.setProdu_nomb(rs.getString("produ_nomb"));
                ven.setProdu_cant(rs.getInt("produ_cant"));
                ven.setFecha(rs.getString("fecha"));
                listado.add(ven);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
}
