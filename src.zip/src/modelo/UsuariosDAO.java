
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class UsuariosDAO {
    
    public UsuariosDAO(){
        }
        
        public static ArrayList<Usuarios> listadoUsuarios(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Usuarios> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_usuarios ORDER BY usu_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Usuarios usuarios = null;
            while(rs.next()){
                usuarios = new Usuarios();
                usuarios.setUsu_codi(rs.getInt("usu_codi"));
                usuarios.setUsu_nomb(rs.getString("usu_nomb"));
                usuarios.setUsu_pass(rs.getString("usu_pass"));
                usuarios.setRol_codi(rs.getInt("rol_codi"));
                listado.add(usuarios);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Usuarios buscarUsuarios(String usu_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Usuarios usuarios = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_usuarios WHERE usu_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, usu_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                usuarios = new Usuarios();
                usuarios.setUsu_codi(rs.getInt("usu_codi"));
                usuarios.setUsu_nomb(rs.getString("usu_nomb"));
                usuarios.setUsu_pass(rs.getString("usu_pass"));
                usuarios.setRol_codi(rs.getInt("rol_codi"));           
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return usuarios;
    }
    
    public int grabarUsuarios(Usuarios c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_usuarios values (?,?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getUsu_codi());
            pstm.setString(2, c.getUsu_nomb());
            pstm.setString(3, c.getUsu_pass());
            pstm.setInt(4,c.getRol_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarUsuarios(Usuarios c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_usuarios " +
                        "SET usu_nomb=?, usu_pass=?, rol_codi=? WHERE usu_codi=?";
            pstm = con.prepareStatement(sql);      
            pstm.setString(1, c.getUsu_nomb());
            pstm.setString(2, c.getUsu_pass());
            pstm.setInt(3,c.getRol_codi());
            pstm.setInt(4,c.getUsu_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarUsuarios(int usu_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_usuarios WHERE usu_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, usu_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Usuarios> listarUsuarios(int usu_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Usuarios> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(usu_codi==0){
                sql = "SELECT * FROM tb_usuarios as m INNER JOIN tb_roles "
                    + "as d ON (d.rol_codi = m.rol_codi) ORDER BY usu_codi";            
            }else{
                sql = "SELECT * FROM tb_usuarios as m INNER JOIN tb_roles "
                    + "as d ON (d.rol_codi = m.rol_codi) where usu_codi = ? "
                    + "ORDER BY usu_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(usu_codi!=0){
                pstm.setInt(1, usu_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Usuarios usuarios = null;
            while(rs.next()){
                usuarios = new Usuarios();
                usuarios.setUsu_codi(rs.getInt("usu_codi"));
                usuarios.setUsu_nomb(rs.getString("usu_nomb"));
                usuarios.setUsu_pass(rs.getString("usu_pass"));
                usuarios.setRol_codi(rs.getInt("rol_codi"));
                usuarios.setRol_nomb(rs.getString("rol_nomb"));
                listado.add(usuarios);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
}
