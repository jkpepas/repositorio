
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class NominaDAO {
    
    
     public NominaDAO(){
        }
     
    public static ArrayList<Nomina> listadoNomina(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Nomina> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_nomina ORDER BY pago_codi";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Nomina nomina = null;
            while(rs.next()){
                nomina = new Nomina();
                nomina.setPago_codi(rs.getInt("pago_codi"));
                nomina.setPago_cant(rs.getInt("pago_cant"));
                nomina.setEmple_codi(rs.getInt("emple_codi"));
                listado.add(nomina);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Nomina buscarNomina(String pago_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Nomina nomina = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_nomina WHERE pago_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, pago_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                nomina = new Nomina();
                nomina.setPago_codi(rs.getInt("pago_codi"));
                nomina.setPago_cant(rs.getInt("pago_cant"));
                nomina.setEmple_codi(rs.getInt("emple_codi"));           
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return nomina;
    }
    
    public int grabarNomina(Nomina c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_nomina values (?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getPago_codi());
            pstm.setInt(2, c.getPago_cant());
            pstm.setInt(3,c.getEmple_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarNomina(Nomina c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_nomina " +
                        "SET pago_cant=?,emple_codi=? WHERE pago_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setInt(1, c.getPago_cant());
            pstm.setInt(2,c.getEmple_codi());
            pstm.setInt(3,c.getPago_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarNomina(int pago_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_nomina WHERE pago_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, pago_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Nomina> listarNomina(int pago_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Nomina> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(pago_codi==0){
                sql = "SELECT * FROM tb_nomina as m INNER JOIN tb_empleados "
                    + "as d ON (d.emple_codi = m.emple_codi) ORDER BY pago_codi";            
            }else{
                sql = "SELECT * FROM tb_nomina as m INNER JOIN tb_empleados "
                    + "as d ON (d.emple_codi = m.emple_codi) where pago_codi = ? "
                    + "ORDER BY pago_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(pago_codi!=0){
                pstm.setInt(1, pago_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Nomina nomina = null;
            while(rs.next()){
                nomina = new Nomina();
                nomina.setPago_codi(rs.getInt("pago_codi"));
                nomina.setPago_cant(rs.getInt("pago_cant"));
                nomina.setEmple_codi(rs.getInt("emple_codi"));
                nomina.setEmple_nomb(rs.getString("emple_nomb"));
                listado.add(nomina);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
}
