package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CiudadesDAO {
        
        public CiudadesDAO(){
        }
        
        public static ArrayList<Ciudades> listadoCiudades(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Ciudades> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_ciudades ORDER BY ciu_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Ciudades ciudad = null;
            while(rs.next()){
                ciudad = new Ciudades();
                ciudad.setCiu_codi(rs.getInt("ciu_codi"));
                ciudad.setCiu_nomb(rs.getString("ciu_nomb"));
                ciudad.setPais_codi(rs.getInt("pais_codi"));
                listado.add(ciudad);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Ciudades buscarCiudades(String ciu_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Ciudades ciudad = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_ciudades WHERE ciu_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, ciu_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                ciudad = new Ciudades();
                ciudad.setCiu_codi(rs.getInt("ciu_codi"));
                ciudad.setCiu_nomb(rs.getString("ciu_nomb"));
                ciudad.setPais_codi(rs.getInt("pais_codi"));           
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return ciudad;
    }
    
    public int grabarCiudades(Ciudades c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_ciudades values (?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getCiu_codi());
            pstm.setString(2, c.getCiu_nomb());
            pstm.setInt(3,c.getCiu_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarCiudades(Ciudades c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_ciudades " +
                        "SET ciu_nomb=?,pais_codi=? WHERE ciu_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getCiu_nomb());
            pstm.setInt(2,c.getPais_codi());
            pstm.setInt(3,c.getCiu_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarCiudades(int ciu_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_ciudades WHERE ciu_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, ciu_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Ciudades> listarCiudades(int ciu_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Ciudades> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(ciu_codi==0){
                sql = "SELECT * FROM tb_ciudades as m INNER JOIN tb_paises "
                    + "as d ON (d.pais_codi = m.pais_codi) ORDER BY ciu_codi";            
            }else{
                sql = "SELECT * FROM tb_ciudades as m INNER JOIN tb_paises "
                    + "as d ON (d.pais_codi = m.pais_codi) where ciu_codi = ? "
                    + "ORDER BY ciu_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(ciu_codi!=0){
                pstm.setInt(1, ciu_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Ciudades ciudad = null;
            while(rs.next()){
                ciudad = new Ciudades();
                ciudad.setCiu_codi(rs.getInt("ciu_codi"));
                ciudad.setCiu_nomb(rs.getString("ciu_nomb"));
                ciudad.setPais_codi(rs.getInt("pais_codi"));
                ciudad.setPais_nomb(rs.getString("pais_nomb"));
                listado.add(ciudad);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
}
