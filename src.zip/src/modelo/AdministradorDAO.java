/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AdministradorDAO {
    
   public AdministradorDAO(){
        
    }
    
    public static ArrayList<Administrador> listadoAdministrador(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Administrador> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_administradores ORDER BY admin_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Administrador admin = null;
            while(rs.next()){
                admin = new Administrador();
                admin.setAdmin_codi(rs.getInt("admin_codi"));
                admin.setAdmin_nomb(rs.getString("admin_nomb"));
                listado.add(admin);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarAdministrador(Administrador p){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_administradores values (?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, p.getAdmin_codi());
            pstm.setString(2, p.getAdmin_nomb());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarAdministrador(Administrador c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_administradores " +
                        "SET admin_nomb=? WHERE admin_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getAdmin_nomb());
            pstm.setInt(2,c.getAdmin_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarAdministrador(int admin_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_administradores WHERE admin_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, admin_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Administrador> listarAdministrador(int admin_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Administrador> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(admin_codi==0){
                sql = "SELECT * FROM tb_administradores  ORDER BY admin_codi";            
            }else{
                sql = "SELECT * FROM tb_administradores  where admin_codi = ? "
                    + "ORDER BY admin_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(admin_codi!=0){
                pstm.setInt(1, admin_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Administrador admin = null;
            while(rs.next()){
                admin = new Administrador();
                admin.setAdmin_codi(rs.getInt("admin_codi"));
                admin.setAdmin_nomb(rs.getString("admin_nomb"));
                listado.add(admin);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Administrador buscarAdministrador(String admin_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Administrador admin = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_administradores WHERE admin_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, admin_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                admin = new Administrador();
                admin.setAdmin_codi(rs.getInt("admin_codi"));
                admin.setAdmin_nomb(rs.getString("admin_nomb"));
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return admin;
    }
    
}


