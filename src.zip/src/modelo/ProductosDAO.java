
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ProductosDAO {
    
    public ProductosDAO(){
        
    }
    
    public static ArrayList<Productos> listadoProductos(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Productos> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_productos ORDER BY produ_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Productos produ = null;
            while(rs.next()){
                produ = new Productos();
                produ.setProdu_codi(rs.getInt("produ_codi"));
                produ.setProdu_nomb(rs.getString("produ_nomb"));
                listado.add(produ);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarProductos(Productos p){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_productos values (?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, p.getProdu_codi());
            pstm.setString(2, p.getProdu_nomb());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarProductos(Productos c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_productos " +
                        "SET produ_nomb=? WHERE produ_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getProdu_nomb());
            pstm.setInt(2,c.getProdu_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarProductos(int produ_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_productos WHERE produ_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, produ_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Productos> listarProductos(int produ_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Productos> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(produ_codi==0){
                sql = "SELECT * FROM tb_productos  ORDER BY produ_codi";            
            }else{
                sql = "SELECT * FROM tb_productos  where produ_codi = ? "
                    + "ORDER BY produ_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(produ_codi!=0){
                pstm.setInt(1, produ_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Productos produ = null;
            while(rs.next()){
                produ = new Productos();
                produ.setProdu_codi(rs.getInt("produ_codi"));
                produ.setProdu_nomb(rs.getString("produ_nomb"));
                listado.add(produ);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Productos buscarProductos(String produ_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Productos produ = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_productos WHERE produ_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, produ_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                produ = new Productos();
                produ.setProdu_codi(rs.getInt("produ_codi"));
                produ.setProdu_nomb(rs.getString("produ_nomb"));
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return produ;
    }
    
}
