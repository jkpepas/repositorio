
package modelo;

public class Ventas {
     private int venta_codi;
    private int cli_codi;
    private String cli_nomb;
    private int produ_codi;
    private String produ_nomb;
    private int produ_cant;
    private String fecha;
    
      public Ventas(){
        venta_codi = 0;
        cli_codi = 0;
        produ_codi = 0;
        produ_cant=0;
        fecha=" ";
    }

    public Ventas(int venta_codi, int cli_codi, String cli_nomb, int produ_codi, String produ_nomb, int produ_cant, String fecha) {
        this.venta_codi = venta_codi;
        this.cli_codi = cli_codi;
        this.cli_nomb = cli_nomb;
        this.produ_codi = produ_codi;
        this.produ_nomb = produ_nomb;
        this.produ_cant = produ_cant;
        this.fecha = fecha;
    }

    public int getVenta_codi() {
        return venta_codi;
    }

    public void setVenta_codi(int venta_codi) {
        this.venta_codi = venta_codi;
    }

    public int getCli_codi() {
        return cli_codi;
    }

    public void setCli_codi(int cli_codi) {
        this.cli_codi = cli_codi;
    }

    public String getCli_nomb() {
        return cli_nomb;
    }

    public void setCli_nomb(String cli_nomb) {
        this.cli_nomb = cli_nomb;
    }

    public int getProdu_codi() {
        return produ_codi;
    }

    public void setProdu_codi(int produ_codi) {
        this.produ_codi = produ_codi;
    }

    public String getProdu_nomb() {
        return produ_nomb;
    }

    public void setProdu_nomb(String produ_nomb) {
        this.produ_nomb = produ_nomb;
    }

    public int getProdu_cant() {
        return produ_cant;
    }

    public void setProdu_cant(int produ_cant) {
        this.produ_cant = produ_cant;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
      

    
      

    
    
}
