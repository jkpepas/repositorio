
package Controlador;
import java.util.ArrayList;
import modelo.Rol;
import modelo.RolDAO;
public class ControladorRol {
    
  public static ArrayList<Rol> listadoRol()
    {
         return RolDAO.listadoRol();
    }
    
    
    public static Rol buscarRol(String rol_codi)
    {
         return RolDAO.buscarRol(rol_codi);
    }
    
    public static int grabarRol(Rol m)
    {
        RolDAO roldadesDAO = new RolDAO();
        int resultado = roldadesDAO.grabarRol(m);
        return resultado; 
    }
    
    public static ArrayList<Rol> listarRol(int rol_codi)
    {
        ArrayList<Rol> listado;
        listado = new ArrayList();
        RolDAO roldadesDAO = new RolDAO();
        listado = roldadesDAO.listarRol(rol_codi);
        return listado; 
    }
    
    public static int borrarRol(int rol_codi)
    {
        RolDAO roldadesDAO = new RolDAO();
        int resultado = roldadesDAO.borrarRol(rol_codi);
        return resultado; 
    }
    
    public static int modificarRol(Rol m)
    {
        RolDAO roldadesDAO = new RolDAO();
        int resultado = roldadesDAO.modificarRol(m);
        return resultado; 
    }
    
}
