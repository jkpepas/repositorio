package modelo;

import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
    
public class Clientes {
    private int cli_codi;
    private String cli_nomb;
    private String cli_ape;
    private int cli_tele;
    
     public Clientes(){
        cli_codi = 0;
        cli_nomb = "";
        cli_ape = "";
        cli_tele=0;
    }

    public Clientes(int cli_codi, String cli_nomb, String cli_ape, int cli_tele) {
        this.cli_codi = cli_codi;
        this.cli_nomb = cli_nomb;
        this.cli_ape = cli_ape;
        this.cli_tele = cli_tele;
    }
     
     
     
    public String toString(){
        return this.getCli_nomb();
    }

    public int getCli_codi() {
        return cli_codi;
    }

    public void setCli_codi(int cli_codi) {
        this.cli_codi = cli_codi;
    }

    public String getCli_nomb() {
        return cli_nomb;
    }

    public void setCli_nomb(String cli_nomb) {
        this.cli_nomb = cli_nomb;
    }

    public String getCli_ape() {
        return cli_ape;
    }

    public void setCli_ape(String cli_ape) {
        this.cli_ape = cli_ape;
    }

    public int getCli_tele() {
        return cli_tele;
    }

    public void setCli_tele(int cli_tele) {
        this.cli_tele = cli_tele;
    }
    
    
}
