
package modelo;
import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Rol {
    private int rol_codi;
    private String rol_nomb;
    private String rol_desc;
    
     public Rol(){
        rol_codi = 0;
        rol_nomb = "";
        rol_desc = "";
        
}

    public Rol(int rol_codi, String rol_nomb, String rol_desc) {
        this.rol_codi = rol_codi;
        this.rol_nomb = rol_nomb;
        this.rol_desc = rol_desc;
    }

    public String toString(){
        return this.getRol_nomb();
    }
    
    public int getRol_codi() {
        return rol_codi;
    }

    public void setRol_codi(int rol_codi) {
        this.rol_codi = rol_codi;
    }

    public String getRol_nomb() {
        return rol_nomb;
    }

    public void setRol_nomb(String rol_nomb) {
        this.rol_nomb = rol_nomb;
    }

    public String getRol_desc() {
        return rol_desc;
    }

    public void setRol_desc(String rol_desc) {
        this.rol_desc = rol_desc;
    }
     
     
    
}
