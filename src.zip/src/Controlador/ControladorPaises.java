/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.util.ArrayList;
import modelo.Paises;
import modelo.PaisesDAO;
public class ControladorPaises {
     
    public static ArrayList<Paises> listadoPaises()
    {
         return PaisesDAO.listadoPaises();
    }
    
    
    public static Paises buscarPaises(String pais_codi)
    {
         return PaisesDAO.buscarPaises(pais_codi);
    }
    
    public static int grabarPaises(Paises g)
    {
        PaisesDAO paisesDAO = new PaisesDAO();
        int resultado = paisesDAO.grabarPaises(g);
        return resultado; 
    }
    
    public static ArrayList<Paises> listarPaises(int pais_codi)
    {
        ArrayList<Paises> listado;
        listado = new ArrayList();
        PaisesDAO paisesDAO = new PaisesDAO();
        listado = paisesDAO.listarPaises(pais_codi);
        return listado; 
    }
    
    public static int borrarPaises(int pais_codi)
    {
        PaisesDAO paisesDAO = new PaisesDAO();
        int resultado = paisesDAO.borrarPaises(pais_codi);
        return resultado; 
    }
    
    public static int modificarPaises(Paises g)
    {
        PaisesDAO paisesDAO = new PaisesDAO();
        int resultado = paisesDAO.modificarPaises(g);
        return resultado; 
    }
}
