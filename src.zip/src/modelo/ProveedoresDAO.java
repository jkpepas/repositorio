
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ProveedoresDAO {
    
    public ProveedoresDAO(){
        
    }
    
    public static ArrayList<Proveedores> listadoProveedores(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Proveedores> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_proveedores ORDER BY prove_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Proveedores prove = null;
            while(rs.next()){
                prove = new Proveedores();
                prove.setProve_codi(rs.getInt("prove_codi"));
                prove.setProve_nomb(rs.getString("prove_nomb"));
                listado.add(prove);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    
    public int grabarProveedores(Proveedores p){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_proveedores values (?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, p.getProve_codi());
            pstm.setString(2, p.getProve_nomb());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }//listo
    
     /**
     * 
     * @param c Objeto de la clase comuna a grabar
     * @return rtdo resultado de la operación modificar
     */
    public int modificarProveedores(Proveedores c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_proveedores " +
                        "SET prove_nomb=? WHERE prove_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getProve_nomb());
            pstm.setInt(2,c.getProve_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
            
    /**
     * 
     * @param comu_codi código de lacomuna a borrar
     * @return rtdo resultado de la operación borrar
     */
    public int borrarProveedores(int prove_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_proveedores WHERE prove_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, prove_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    /**
     * 
     * @param comu_codi codigo de comuna a listar, 0 se listaran todas
     * @return ArrayList, lista de objetos Comuna
     */
    public ArrayList<Proveedores> listarProveedores(int prove_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Proveedores> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(prove_codi==0){
                sql = "SELECT * FROM tb_proveedores  ORDER BY prove_codi";            
            }else{
                sql = "SELECT * FROM tb_proveedores  where prove_codi = ? "
                    + "ORDER BY prove_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(prove_codi!=0){
                pstm.setInt(1, prove_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Proveedores prove = null;
            while(rs.next()){
                prove = new Proveedores();
                prove.setProve_codi(rs.getInt("prove_codi"));
                prove.setProve_nomb(rs.getString("prove_nomb"));
                listado.add(prove);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    public static Proveedores buscarProveedores(String prove_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Proveedores prove = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_proveedores WHERE prove_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, prove_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                prove = new Proveedores();
                prove.setProve_codi(rs.getInt("prove_codi"));
                prove.setProve_nomb(rs.getString("prove_nomb"));
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return prove;
    }
}
