
package Controlador;

import java.util.ArrayList;
import modelo.Propietarios;
import modelo.PropietariosDAO;
import modelo.Propietarios;
import modelo.PropietariosDAO;

public class ControladorPropietarios {
    public static ArrayList<Propietarios> listadoPropietarios()
    {
         return PropietariosDAO.listadoPropietarios();
    }
    
    
    public static Propietarios buscarPropietarios(String propi_codi)
    {
         return PropietariosDAO.buscarPropietarios(propi_codi);
    }
    
    public static int grabarPropietarios(Propietarios p)
    {
        PropietariosDAO propietariosDAO = new PropietariosDAO();
        int resultado = propietariosDAO.grabarPropietarios(p);
        return resultado; 
    }
    
    public static ArrayList<Propietarios> listarPropietarios(int propi_codi)
    {
        ArrayList<Propietarios> listado;
        listado = new ArrayList();
        PropietariosDAO propietariosDAO = new PropietariosDAO();
        listado = propietariosDAO.listarPropietarios(propi_codi);
        return listado; 
    }
    
    public static int borrarPropietarios(int propi_codi)
    {
        PropietariosDAO propietariosDAO = new PropietariosDAO();
        int resultado = propietariosDAO.borrarPropietarios(propi_codi);
        return resultado; 
    }
    
    public static int modificarPropietarios(Propietarios m)
    {
        PropietariosDAO propietariosDAO = new PropietariosDAO();
        int resultado = propietariosDAO.modificarPropietarios(m);
        return resultado; 
    }
}
