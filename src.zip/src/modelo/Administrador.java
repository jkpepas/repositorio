
package modelo;
import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Administrador {
    private int admin_codi;
    private String admin_nomb;
    
     public Administrador(){
        admin_codi = 0;
        admin_nomb = "";
        
}

    public Administrador(int admin_codi, String admin_nomb) {
        this.admin_codi = admin_codi;
        this.admin_nomb = admin_nomb;
    }
    public String toString(){
        return this.getAdmin_nomb();
    }
    public int getAdmin_codi() {
        return admin_codi;
    }

    public void setAdmin_codi(int admin_codi) {
        this.admin_codi = admin_codi;
    }

    public String getAdmin_nomb() {
        return admin_nomb;
    }

    public void setAdmin_nomb(String admin_nomb) {
        this.admin_nomb = admin_nomb;
    }
     
}
