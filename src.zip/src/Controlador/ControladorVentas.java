/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.util.ArrayList;
import modelo.Ventas;
import modelo.VentasDAO;

/**
 *
 * @author pablo
 */
public class ControladorVentas {
    
    public static ArrayList<Ventas> listadoVentas()
    {
         return VentasDAO.listadoVentas();
    }
    
    
    public static Ventas buscarVentas(String venta_codi)
    {
         return VentasDAO.buscarVentas(venta_codi);
    }
    
    public static int grabarVentas(Ventas m)
    {
        VentasDAO ventasDAO = new VentasDAO();
        int resultado = ventasDAO.grabarVentas(m);
        return resultado; 
    }
    
    public static ArrayList<Ventas> listarVentas(int venta_codi)
    {
        ArrayList<Ventas> listado;
        listado = new ArrayList();
        VentasDAO ventasDAO = new VentasDAO();
        listado = ventasDAO.listarVentas(venta_codi);
        return listado; 
    }
    
    public static int borrarVentas(int venta_codi)
    {
        VentasDAO ventasDAO = new VentasDAO();
        int resultado = ventasDAO.borrarVentas(venta_codi);
        return resultado; 
    }
    
    public static int modificarVentas(Ventas m)
    {
        VentasDAO ventasDAO = new VentasDAO();
        int resultado = ventasDAO.modificarVentas(m);
        return resultado; 
    }
    
}
