
package modelo;

import Servicios.Conexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Farmacias {
    private int farma_codi;
    private String farma_nomb;
    private int ciu_codi;
    private String ciu_nomb;
    private int admin_codi;
    private String admin_nomb;
    private int propi_codi;
    private String propi_nomb;
    
    public Farmacias(){
        farma_codi = 0;
        farma_nomb = "";
        ciu_codi=0;
        admin_codi = 0;
        propi_codi = 0;
    }

    public Farmacias(int farma_codi, String farma_nomb, int ciu_codi, String ciu_nomb, int admin_codi, String admin_nomb, int propi_codi, String propi_nomb) {
        this.farma_codi = farma_codi;
        this.farma_nomb = farma_nomb;
        this.ciu_codi = ciu_codi;
        this.ciu_nomb = ciu_nomb;
        this.admin_codi = admin_codi;
        this.admin_nomb = admin_nomb;
        this.propi_codi = propi_codi;
        this.propi_nomb = propi_nomb;
    }
    
      public String toString(){
        return this.getFarma_nomb();
    }

    public int getFarma_codi() {
        return farma_codi;
    }

    public void setFarma_codi(int farma_codi) {
        this.farma_codi = farma_codi;
    }

    public String getFarma_nomb() {
        return farma_nomb;
    }

    public void setFarma_nomb(String farma_nomb) {
        this.farma_nomb = farma_nomb;
    }

    public int getCiu_codi() {
        return ciu_codi;
    }

    public void setCiu_codi(int ciu_codi) {
        this.ciu_codi = ciu_codi;
    }

    public String getCiu_nomb() {
        return ciu_nomb;
    }

    public void setCiu_nomb(String ciu_nomb) {
        this.ciu_nomb = ciu_nomb;
    }

    public int getAdmin_codi() {
        return admin_codi;
    }

    public void setAdmin_codi(int admin_codi) {
        this.admin_codi = admin_codi;
    }

    public String getAdmin_nomb() {
        return admin_nomb;
    }

    public void setAdmin_nomb(String admin_nomb) {
        this.admin_nomb = admin_nomb;
    }

    public int getPropi_codi() {
        return propi_codi;
    }

    public void setPropi_codi(int propi_codi) {
        this.propi_codi = propi_codi;
    }

    public String getPropi_nomb() {
        return propi_nomb;
    }

    public void setPropi_nomb(String propi_nomb) {
        this.propi_nomb = propi_nomb;
    }
    
    
}
