
package Controlador;

import java.util.ArrayList;
import modelo.Proveedores;
import modelo.ProveedoresDAO;
public class ControladorProveedores {
 
    
     public static ArrayList<Proveedores> listadoProveedores()
    {
         return ProveedoresDAO.listadoProveedores();
    }
    
    
    public static Proveedores buscarProveedores(String prove_codi)
    {
         return ProveedoresDAO.buscarProveedores(prove_codi);
    }
    
    public static int grabarProveedores(Proveedores p)
    {
        ProveedoresDAO proveedoresDAO = new ProveedoresDAO();
        int resultado = proveedoresDAO.grabarProveedores(p);
        return resultado; 
    }
    
    public static ArrayList<Proveedores> listarProveedores(int prove_codi)
    {
        ArrayList<Proveedores> listado;
        listado = new ArrayList();
        ProveedoresDAO proveedoresDAO = new ProveedoresDAO();
        listado = proveedoresDAO.listarProveedores(prove_codi);
        return listado; 
    }
    
    public static int borrarProveedores(int prove_codi)
    {
        ProveedoresDAO proveedoresDAO = new ProveedoresDAO();
        int resultado = proveedoresDAO.borrarProveedores(prove_codi);
        return resultado; 
    }
    
    public static int modificarProveedores(Proveedores m)
    {
        ProveedoresDAO proveedoresDAO = new ProveedoresDAO();
        int resultado = proveedoresDAO.modificarProveedores(m);
        return resultado; 
    }
}
