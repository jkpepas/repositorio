
package Controlador;
import java.util.ArrayList;
import modelo.Nomina;
import modelo.NominaDAO;
public class ControladorNomina {
    
  public static ArrayList<Nomina> listadoNomina()
    {
         return NominaDAO.listadoNomina();
    }
    
    
    public static Nomina buscarNomina(String pago_codi)
    {
         return NominaDAO.buscarNomina(pago_codi);
    }
    
    public static int grabarNomina(Nomina m)
    {
        NominaDAO empleadosDAO = new NominaDAO();
        int resultado = empleadosDAO.grabarNomina(m);
        return resultado; 
    }
    
    public static ArrayList<Nomina> listarNomina(int pago_codi)
    {
        ArrayList<Nomina> listado;
        listado = new ArrayList();
        NominaDAO nominaDAO = new NominaDAO();
        listado = nominaDAO.listarNomina(pago_codi);
        return listado; 
    }
    
    public static int borrarNomina(int pago_codi)
    {
        NominaDAO nominaDAO = new NominaDAO();
        int resultado = nominaDAO.borrarNomina(pago_codi);
        return resultado; 
    }
    
    public static int modificarNomina(Nomina m)
    {
        NominaDAO nominaDAO = new NominaDAO();
        int resultado = nominaDAO.modificarNomina(m);
        return resultado; 
    }
    
}
