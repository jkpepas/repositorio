
package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class FarmaciasDAO {
    
    public FarmaciasDAO(){
        
    }
    
    public static ArrayList<Farmacias> listadoFarmacias(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Farmacias> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_farmacias ORDER BY farma_nomb";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Farmacias farma = null;
            while(rs.next()){
                farma = new Farmacias();
                farma.setFarma_codi(rs.getInt("farma_codi"));
                farma.setFarma_nomb(rs.getString("farma_nomb"));
                farma.setCiu_codi(rs.getInt("ciu_codi"));
                farma.setAdmin_codi(rs.getInt("admin_codi"));
                farma.setPropi_codi(rs.getInt("propi_codi"));
                listado.add(farma);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Farmacias buscarFarmacias(String farma_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Farmacias farma = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_farmacias WHERE farma_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, farma_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                farma = new Farmacias();
                farma.setFarma_codi(rs.getInt("farma_codi"));
                farma.setFarma_nomb(rs.getString("farma_nomb"));
                farma.setCiu_codi(rs.getInt("ciu_codi"));
                farma.setAdmin_codi(rs.getInt("admin_codi"));
                farma.setPropi_codi(rs.getInt("propi_codi"));  
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return farma;
    }
    
    public int grabarFarmacias(Farmacias c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_farmacias values (?,?,?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getFarma_codi());
            pstm.setString(2, c.getFarma_nomb());
            pstm.setInt(3, c.getCiu_codi());
            pstm.setInt(4, c.getAdmin_codi());
            pstm.setInt(5,c.getPropi_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarFarmacias(Farmacias c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_farmacias " +
                        "SET farma_nomb=?,ciu_codi=?,admin_codi=?,propi_codi=? WHERE farma_codi=?";
            pstm = con.prepareStatement(sql);            
            pstm.setString(1, c.getFarma_nomb());
            pstm.setInt(2,c.getCiu_codi());
            pstm.setInt(3,c.getAdmin_codi());
            pstm.setInt(4, c.getPropi_codi());
            pstm.setInt(5,c.getFarma_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarFarmacias(int farma_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_farmacias WHERE farma_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, farma_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Farmacias> listarFarmacias(int farma_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Farmacias> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(farma_codi==0){
                sql = "SELECT * FROM tb_farmacias as m "
                        + "INNER JOIN tb_ciudades "
                        + " as d ON (d.ciu_codi = m.ciu_codi) "
                        + "INNER JOIN tb_administradores"
                        + " as a ON (a.admin_codi = m.admin_codi) "
                        + "INNER JOIN tb_propietarios"
                        + " as p ON (p.propi_codi = m.propi_codi) "
                        + "ORDER BY farma_codi"
                        ;            
            }else{
                sql = "SELECT * FROM tb_farmacias as m "
                        + "INNER JOIN tb_ciudades "
                        + " as d ON (d.ciu_codi = m.ciu_codi) "
                        + "INNER JOIN tb_administradores"
                        + " as a ON (a.admin_codi = m.admin_codi) "
                        + "INNER JOIN tb_propietarios"
                        + " as p ON (p.propi_codi = m.propi_codi) "
                        + "where farma_codi = ? "
                        + "ORDER BY farma_codi";       
            }                        
            pstm = con.prepareStatement(sql);
            
            if(farma_codi!=0){
                pstm.setInt(1, farma_codi);
            }
            
            rs = pstm.executeQuery();
                        
            Farmacias farma = null;
            while(rs.next()){
                farma = new Farmacias();
                farma.setFarma_codi(rs.getInt("farma_codi"));
                farma.setFarma_nomb(rs.getString("farma_nomb"));
                farma.setCiu_codi(rs.getInt("ciu_codi"));
                farma.setCiu_nomb(rs.getString("ciu_nomb"));
                farma.setAdmin_codi(rs.getInt("admin_codi"));
                farma.setAdmin_nomb(rs.getString("admin_nomb"));
                farma.setPropi_codi(rs.getInt("propi_codi"));
                farma.setPropi_nomb(rs.getString("propi_nomb"));
                listado.add(farma);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
}
