package modelo;

import Servicios.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class InventariosDAO {
        
        public InventariosDAO(){
        }
        
        public static ArrayList<Inventarios> listadoInventarios(){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Inventarios> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_inventarios ORDER BY inven_codi";
            
            pstm = con.prepareStatement(sql);
            
            rs = pstm.executeQuery();
            
            Inventarios inventario = null;
            while(rs.next()){
                inventario = new Inventarios();
                inventario.setInven_codi(rs.getInt("inven_codi"));
                inventario.setProdu_codi(rs.getInt("produ_codi"));
                inventario.setCant(rs.getInt("cant"));
                inventario.setFecha(rs.getString("fecha"));
                listado.add(inventario);
            }
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
    /**
     * 
     * @param muni_codi codigo del municipio a buscar
     * @return Objeto de municipio
     */
    public static Inventarios buscarInventarios(String inven_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        Inventarios inventario = null;
        try{
            con = Conexion.getConnection();
            String sql = "SELECT * FROM tb_inventarios WHERE inven_codi = ? ";
                   
            pstm = con.prepareStatement(sql);
            pstm.setString(1, inven_codi);
            
            rs = pstm.executeQuery();

            
            while(rs.next()){
                inventario = new Inventarios();
                inventario.setInven_codi(rs.getInt("inven_codi"));
                inventario.setProdu_codi(rs.getInt("produ_codi"));
                inventario.setCant(rs.getInt("cant"));
                inventario.setFecha(rs.getString("fecha"));           
            }
           
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
         return inventario;
    }
    
    public int grabarInventarios(Inventarios c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "INSERT INTO tb_inventarios values (?,?,?,?)";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getInven_codi());
            pstm.setInt(2, c.getProdu_codi());
            pstm.setInt(3, c.getCant());
            pstm.setString(4, c.getFecha());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int modificarInventarios(Inventarios c){      
        Connection con = null;
        PreparedStatement pstm;
        pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "UPDATE tb_inventarios " +
                        "SET produ_codi=?,cant=?, fecha=? WHERE inven_codi=?";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, c.getProdu_codi());
            pstm.setInt(2, c.getCant());
            pstm.setString(3, c.getFecha()); 
            pstm.setInt(4, c.getInven_codi());
            rtdo = pstm.executeUpdate();  
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public int borrarInventarios(int inven_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        int rtdo;
        rtdo = 0;
        try{
            con = Conexion.getConnection();
            String sql = "DELETE FROM tb_inventarios WHERE inven_codi = ? ";
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, inven_codi);
            rtdo = pstm.executeUpdate(); 
            return rtdo;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        return rtdo;
    }
    
    public ArrayList<Inventarios> listarInventarios(int inven_codi){      
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Inventarios> listado = new ArrayList<>();
        try{
            con = Conexion.getConnection();
            String sql="";
            if(inven_codi==0){
                sql = "SELECT * FROM tb_inventarios as m INNER JOIN tb_productos "
                    + "as d ON (d.produ_codi = m.produ_codi) ORDER BY inven_codi";            
            }else{
                sql = "SELECT * FROM tb_inventarios as m INNER JOIN tb_productos "
                    + "as d ON (d.produ_codi = m.produ_codi) where inven_codi = ? "
                    + "ORDER BY inven_codi";      
            }                        
            pstm = con.prepareStatement(sql);
            
            if(inven_codi!=0){
                pstm.setInt(1, inven_codi);
            }
            
            rs = pstm.executeQuery();
                        
                Inventarios inventario = null;
            while(rs.next()){
                inventario = new Inventarios();
                inventario.setInven_codi(rs.getInt("inven_codi"));
                inventario.setProdu_codi(rs.getInt("produ_codi"));
                inventario.setProdu_nomb(rs.getString("produ_nomb"));
                inventario.setCant(rs.getInt("cant"));
                inventario.setFecha(rs.getString("fecha"));
                listado.add(inventario);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
        }
        finally{
            try{
                if(rs!=null) rs.close();
                if(pstm!=null) pstm.close();                
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null,"Código : " + 
                        ex.getErrorCode() + "\nError :" + ex.getMessage());
            }
        }
        return listado;
    }
    
}